Bodybuilding poses (no Animation Editor, no publishing). Studio is the source of truth, no Rojo.

The poses are already made and checked on Robloxian 2.0 with the muscles: see preview_poses.png
(Relaxed, FrontDoubleBiceps, FrontLatSpread, SideChest, AbsAndThigh, MostMuscular, BackDoubleBiceps).
They are played procedurally by setting Motor6D.Transform, so they work in the live game right away.

STEPS
1. Put poses/PoseData.lua in ReplicatedStorage as a ModuleScript named "PoseData" (copy exactly).
2. Put poses/PoseController.client.lua in StarterPlayerScripts as a LocalScript "PoseController".
3. Server: to pose someone, set character:SetAttribute("Pose", "MostMuscular") (any PoseData name).
   Set it to "" to release. Poses replicate because every client reads the attribute and poses every character.
   NPCs: tag the NPC model "Poser" with CollectionService (the controller picks them up), then set the attribute.
4. While posing: anchor/zero WalkSpeed + JumpPower, face the camera/judges, and show the pose name on screen.
   Walking or jumping cancels the pose (set "" again).
5. Hook it up: emote wheel entries for each pose, posing stage (judges score the pose), mirror, statue
   (statue = a cloned rig posed once, then anchored), progress mirror "Now" preview, NPCs on the posing stage.
6. Juice on pose hit: short camera punch, a flash, the trained muscles briefly +4% (PUMPED pulse), a crowd
   "ooh" sound (placeholder id in Sounds config).
7. If a joint looks wrong on the real rig (e.g. a package with rotated RigAttachments), the controller already
   converts angles into each joint's C0 frame. If something still bends the wrong way, flip the sign of that
   joint's number in PoseData and tell me which one.

TEST: play every pose on a player and an NPC, at level 0 and max muscles, with a shirt on; screenshot each
into screenshots/poses_<name>.png; make sure blending in/out is smooth and walking cancels it.
Commit + push, update PROGRESS.md.
