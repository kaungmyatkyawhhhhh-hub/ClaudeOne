Muscle system v7: REAL growth. Replaces every earlier muscle version (v4/v5/v6, blobs, pieces).
Studio is the source of truth, no Rojo.

WHY: before, muscles were scaled out from the middle of the body part, so they looked like they slid out of
the body. Now each muscle's outline stays on the skin and only the bulge rises, using EditableMesh.

FILES (muscle_v7/)
- growdata/<Part>__<Muscle>.json: per muscle: base (flat on skin), max (full bulge), tris. Part-local studs,
  origin = body part position, +X = character's right, +Y up, -Z front. Fitted to Robloxian 2.0 (bundle 311).
- manifest.json: part, muscle, shorts flag, stat mapping and the growth formula.
- meshes_max/ and meshes_base/: the same shapes as OBJ (for previews/fallback only).
- body/: snatched-waist UpperTorso + LowerTorso replacement meshes.
- textures/: skin + rock (mass monster) maps. preview_growth.png shows level 0 / 15 / 35 / 70 / max.

STEPS
1. Enable mesh APIs: Game Settings > Security > "Allow Mesh / Image APIs" (EditableMesh). If you can't toggle it,
   tell me exactly where to click.
2. Convert each growdata JSON into a ModuleScript under ReplicatedStorage/MuscleData (split big ones into several
   modules if a script gets too long). Keep the numbers exactly.
3. Per character (client-side for rendering; each client builds every visible character's muscles):
   for each muscle: AssetService:CreateEditableMesh(), AddVertex for every base vertex, AddTriangle for tris,
   then AssetService:CreateMeshPartAsync(Content.fromObject(editableMesh)) -> MeshPart, weld to the body part
   at CFrame.new() (origin = part center). Massless, no collision/query/touch. MuscleName attribute.
4. Growth: g = muscle level / max level. Set every vertex to base + (max - base) * g with SetPosition, tween g over
   ~0.4s on level-up. Hide the MeshPart while g < 0.02 (level 0 = plain Robloxian 2.0).
   PUMPED: briefly g * 1.04. Mass monster (above max): g up to 1.12 + RockSkin.
5. Skin SurfaceAppearance tinted to BodyColors; shorts=true meshes use the shorts color. Snatched torso meshes
   replace UpperTorso/LowerTorso for everyone. Gym shorts end at the shorts line.
6. Performance: only update vertices when g changes; build muscles only for characters within ~100 studs;
   pool/reuse EditableMeshes. Test on a phone with 10+ players.
7. FALLBACK if EditableMesh can't be used: import meshes_base and meshes_max, show base at low levels and
   max at high levels, swapping with a short pulse. Tell me if you had to use the fallback.
8. Remove all older muscle code and parts.

TEST: screenshots at level 0, 15%, 35%, 70%, max, monster (front/back/side), level-up tween, walking + lifting.
Compare with preview_growth.png. Commit + push, update PROGRESS.md.
