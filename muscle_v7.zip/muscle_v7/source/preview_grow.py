import sys, os, json, numpy as np
sys.path.insert(0, '..')
from raster import Canvas, load, rotY, rotX
from PIL import Image, ImageDraw
import preview_rb as P
def render(R, g, path):
    c = Canvas(420, 560, bg=(0.15, 0.15, 0.17))
    # body (reuse preview_rb body drawing at level None)
    P.render(R, None, path)
    c.img = np.asarray(Image.open(path), float) / 255; c.z[:] = -1e9
    # redraw body into zbuffer
    c2 = Canvas(420, 560, bg=(0.15, 0.15, 0.17))
    for nm, (V, F) in P.BODY.items():
        col = P.SKIN
        if "UpperLeg" in nm:
            cy = (V[:, 1].min() + V[:, 1].max()) / 2; Hr = np.ptp(V[:, 1]); cut = cy + 0.12 * Hr * 0.94 / 1.2
            up = V[F].mean(1)[:, 1] > cut
            c2.draw(V - P.ORIGIN, F[up], P.SHORTS, R=R, scale=110, offset=(0, 35), spec=0.12)
            c2.draw(V - P.ORIGIN, F[~up], P.SKIN, R=R, scale=110, offset=(0, 35), spec=0.12); continue
        if nm == "LowerTorso": col = P.SHORTS
        c2.draw(V - P.ORIGIN, F, col, R=R, scale=110, offset=(0, 35), spec=0.12)
    if g > 0:
        d0 = 'stages/g0'; d1 = 'stages/g1'
        for m in P.MAN["meshes"]:
            V0, F = load(os.path.join(d0, m["file"])); V1, _ = load(os.path.join(d1, m["file"]))
            V = V0 + (V1 - V0) * g
            ctr = np.array(P.MAN["parts"][m["part"]]["bbox_center_world_in_export"])
            c2.draw(V + ctr - P.ORIGIN, F, P.SHORTS if m.get("shorts") else P.SKIN, R=R, scale=110, offset=(0, 35), spec=0.25, gloss=40)
    c2.save(path)
r = rotX(0.06) @ rotY(np.pi * 0.85)
tiles = []
for g, lab in ((0, 'level 0'), (0.15, '15%'), (0.35, '35%'), (0.7, '70%'), (1, 'MAX')):
    render(r, g, 'out/tmp.png'); im = Image.open('out/tmp.png').copy(); ImageDraw.Draw(im).text((8, 6), lab, fill=(230, 230, 230)); tiles.append(im)
s = Image.new('RGB', (sum(t.width for t in tiles), tiles[0].height)); x = 0
for t in tiles: s.paste(t, (x, 0)); x += t.width
s.save('out/preview_growth.png'); print('ok')
