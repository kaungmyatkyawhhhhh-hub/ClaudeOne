"""Tiny z-buffer rasterizer with smooth shading, for previews."""
import numpy as np

def load(p):
    V, F = [], []
    for line in open(p):
        if line.startswith("v "): V.append([float(x) for x in line.split()[1:4]])
        elif line.startswith("f "): F.append([int(t.split("/")[0]) - 1 for t in line.split()[1:4]])
    return np.array(V), np.array(F)

def vnormals(V, F):
    N = np.zeros_like(V)
    fn = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    for k in range(3): np.add.at(N, F[:, k], fn)
    return N / (np.linalg.norm(N, axis=1, keepdims=True) + 1e-9)

def rotY(a):
    c, s = np.cos(a), np.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def rotX(a):
    c, s = np.cos(a), np.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])

class Canvas:
    def __init__(self, W, H, bg=(0.13, 0.13, 0.14)):
        self.W, self.H = W, H
        self.img = np.ones((H, W, 3)) * np.array(bg)
        self.z = np.full((H, W), -1e9)

    def draw(self, V, F, color, R=np.eye(3), scale=100, offset=(0, 0), light=(-0.4, 0.5, 0.8), spec=0.3, gloss=30, N=None):
        if N is None: N = vnormals(V, F)
        Vr = V @ R.T; Nr = N @ R.T
        L = np.array(light, float); L /= np.linalg.norm(L)
        Hh = L + np.array([0, 0, 1.0]); Hh /= np.linalg.norm(Hh)
        sx = Vr[:, 0] * scale + self.W / 2 + offset[0]
        sy = -Vr[:, 1] * scale + self.H / 2 + offset[1]
        color = np.array(color)
        for f in F:
            x = sx[f]; y = sy[f]; zz = Vr[f, 2]
            x0, x1 = int(max(0, np.floor(x.min()))), int(min(self.W - 1, np.ceil(x.max())))
            y0, y1 = int(max(0, np.floor(y.min()))), int(min(self.H - 1, np.ceil(y.max())))
            if x1 < x0 or y1 < y0: continue
            den = (y[1] - y[2]) * (x[0] - x[2]) + (x[2] - x[1]) * (y[0] - y[2])
            if abs(den) < 1e-9: continue
            X, Y = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
            w0 = ((y[1] - y[2]) * (X - x[2]) + (x[2] - x[1]) * (Y - y[2])) / den
            w1 = ((y[2] - y[0]) * (X - x[2]) + (x[0] - x[2]) * (Y - y[2])) / den
            w2 = 1 - w0 - w1
            m = (w0 >= -1e-6) & (w1 >= -1e-6) & (w2 >= -1e-6)
            if not m.any(): continue
            Z = w0 * zz[0] + w1 * zz[1] + w2 * zz[2]
            zb = self.z[y0:y1 + 1, x0:x1 + 1]
            m &= Z > zb
            if not m.any(): continue
            n = w0[..., None] * Nr[f[0]] + w1[..., None] * Nr[f[1]] + w2[..., None] * Nr[f[2]]
            n /= np.linalg.norm(n, axis=-1, keepdims=True) + 1e-9
            d = np.clip(n @ L, 0, 1); s = np.clip(n @ Hh, 0, 1) ** gloss
            amb = 0.35 + 0.15 * np.clip(n[..., 1], -1, 1)
            c = color * (amb + 0.6 * d)[..., None] + spec * s[..., None]
            zb[m] = Z[m]
            self.img[y0:y1 + 1, x0:x1 + 1][m] = np.clip(c[m], 0, 1)

    def save(self, p):
        from PIL import Image
        Image.fromarray((self.img * 255).astype("uint8")).save(p)
