import numpy as np
def load_groups(p):
    V=[];groups={};cur=None
    for line in open(p):
        if line.startswith('v '): V.append([float(x) for x in line.split()[1:4]])
        elif line.startswith('g '): cur=line.split()[1]; groups.setdefault(cur,[])
        elif line.startswith('f '):
            groups[cur].append([int(t.split('/')[0])-1 for t in line.split()[1:]])
    V=np.array(V)
    out={}
    for g,F in groups.items():
        tris=[]
        for f in F:
            for i in range(1,len(f)-1): tris.append((f[0],f[i],f[i+1]))
        F=np.array(tris)
        u=np.unique(F); m={o:i for i,o in enumerate(u)}
        out[g]=(V[u], np.vectorize(m.get)(F))
    return out
