"""Build GYM ARC muscle shells fitted to the REAL Robloxian 2.0 body (exported from Studio),
plus a snatched-waist torso (UpperTorso/LowerTorso replacement meshes)."""
import sys, os, json, glob, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "v2")); sys.path.insert(0, os.path.join(HERE, ".."))
import anat
from anat import Section, write_obj
import parts as PT
from loadrb import load_groups

GROW = float(os.environ.get("GROW", "1"))
anat.GROW = GROW
OUT = os.path.join(HERE, os.environ.get("OUTDIR", "out")); os.makedirs(OUT, exist_ok=True)
for f in glob.glob(os.path.join(OUT, "*.obj")): os.remove(f)
anat.OUT = OUT

G = load_groups("/mnt/user-data/uploads/Downloads/robloxian2.obj")
NAMES = {"Robloxian2export14": "UpperTorso", "Robloxian2export13": "LowerTorso",
         "Robloxian2export12": "RightUpperArm", "Robloxian2export11": "RightLowerArm", "Robloxian2export10": "RightHand",
         "Robloxian2export9": "LeftUpperArm", "Robloxian2export8": "LeftLowerArm", "Robloxian2export7": "LeftHand",
         "Robloxian2export1": "RightUpperLeg", "Robloxian2export2": "RightLowerLeg", "Robloxian2export3": "RightFoot",
         "Robloxian2export4": "LeftUpperLeg", "Robloxian2export5": "LeftLowerLeg", "Robloxian2export6": "LeftFoot",
         "Robloxian2export15": "Head"}
BODY = {NAMES[g]: (V.copy(), F) for g, (V, F) in G.items()}
ORIGIN = np.array([0.0, 34.6, -250.0])   # preview origin only

# ---------- snatched waist: taper the torso smoothly from ribs to waist ----------
WAIST_Y = 34.72
def waist_factor(y, ax, az):
    t = np.exp(-((y - WAIST_Y) / 0.62) ** 2)
    return 1 - ax * t, 1 - az * t
for nm in ("UpperTorso", "LowerTorso"):
    V, F = BODY[nm]
    fx, fz = waist_factor(V[:, 1], 0.24, 0.10)
    V2 = V.copy(); V2[:, 0] *= fx; V2[:, 2] = -250.0 + (V[:, 2] + 250.0) * fz
    BODY[nm] = (V2, F)

def bbox_center(V): return (V.min(0) + V.max(0)) / 2

# ---------- ray casting onto a body part ----------
def raycast(V, F, O, D):
    """O: (N,3) origins, D: (N,3) dirs. Returns farthest-from-axis hit t (outer surface)."""
    v0, v1, v2 = V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]
    e1, e2 = v1 - v0, v2 - v0
    T = np.full(len(O), np.nan)
    for a in range(0, len(O), 2048):
        o = O[a:a + 2048, None, :]; d = D[a:a + 2048, None, :]
        p = np.cross(d, e2[None]); det = np.einsum("nkj,kj->nk", p, e1)
        inv = 1 / np.where(np.abs(det) < 1e-12, np.nan, det)
        tv = o - v0[None]; u = np.einsum("nkj,nkj->nk", tv, p) * inv
        q = np.cross(tv, e1[None]); v = np.einsum("nkj,nkj->nk", d, q) * inv
        t = np.einsum("kj,nkj->nk", e2, q) * inv
        ok = (u >= -1e-6) & (v >= -1e-6) & (u + v <= 1 + 1e-6) & (t > 0)
        t = np.where(ok, t, np.nan)
        with np.errstate(all="ignore"):
            T[a:a + 2048] = np.nanmin(t, axis=1)
    return T

def dense_points(V, F, n=6):
    pts = [V]
    for i in range(1, n):
        for j in range(0, n - i + 1):
            a, b = i / n, j / n
            if a + b > 1: continue
            pts.append(V[F[:, 0]] * (1 - a - b) + V[F[:, 1]] * a + V[F[:, 2]] * b)
    return np.concatenate(pts)

def make_surface(V, F, tmpl_sec, Ht, mirror, nexp=4.0):
    """Smooth fitted surface: per-height rounded-box slice matched to the real mesh extents."""
    from scipy.ndimage import gaussian_filter1d
    c = bbox_center(V); Hr = (V.max(0) - V.min(0))[1]
    ymin, ymax = V[:, 1].min(), V[:, 1].max()
    P = dense_points(V, F, 8)
    ys = np.linspace(ymin, ymax, 48)
    ext = []
    for yy in ys:
        m = np.abs(P[:, 1] - yy) < (ymax - ymin) / 40
        if m.sum() < 8: m = np.argsort(np.abs(P[:, 1] - yy))[:40]
        Q = P[m]
        ext.append([np.percentile(Q[:, 0], 1), np.percentile(Q[:, 0], 99), np.percentile(Q[:, 2], 1), np.percentile(Q[:, 2], 99)])
    ext = gaussian_filter1d(np.array(ext), 2.0, axis=0, mode="nearest")
    cxs = (ext[:, 0] + ext[:, 1]) / 2; czs = (ext[:, 2] + ext[:, 3]) / 2
    axs = (ext[:, 1] - ext[:, 0]) / 2; azs = (ext[:, 3] - ext[:, 2]) / 2
    Wt = tmpl_sec.P[:, 0].max(); Dt = tmpl_sec.P[:, 1].max()

    def surf(SV, YV):
        x, z, nx, nz = tmpl_sec.at(SV)
        if mirror: x, nx = -x, -nx
        yw = c[1] + YV / Ht * Hr * 0.94
        cx = np.interp(yw, ys, cxs); cz = np.interp(yw, ys, czs)
        ax = np.interp(yw, ys, axs); az = np.interp(yw, ys, azs)
        Px = cx + x / Wt * ax; Pz = cz + z / Dt * az
        Pt = np.stack([Px, yw, Pz], -1)
        # normal: scaled template normal + slope along y from the grid
        N0 = np.stack([nx / ax, 0 * nx, nz / az], -1)
        N0 /= np.linalg.norm(N0, axis=-1, keepdims=True)
        dY = np.gradient(Pt, axis=0)
        dS = np.roll(Pt, -1, 1) - np.roll(Pt, 1, 1)
        N = np.cross(dY, dS)
        N *= np.sign(np.sum(N * N0, -1, keepdims=True) + 1e-12)
        N /= np.linalg.norm(N, axis=-1, keepdims=True) + 1e-9
        N = 0.5 * N + 0.5 * N0; N /= np.linalg.norm(N, axis=-1, keepdims=True)
        return Pt - c, N
    return surf

LIMB_H = 0.95
manifest = {"coords": "Part-local studs, origin = the body part's mesh bounding-box center (= MeshPart position). "
            "+X = character's right, +Y up, -Z front. Fitted to Robloxian 2.0 (bundle 311) at default scale.",
            "parts": {}, "meshes": []}
for name, W, D, H, regs, mir, veins, _ in PT.PARTS:
    p = PT.make(name, W, D, H, regs, mir, veins); p.build()
    sides = [(name, False)]
    if name.startswith("Right"): sides.append(("Left" + name[5:], True))
    for real, mirror in sides:
        V, F = BODY[real]
        p.name = real
        p.surface = make_surface(V, F, p.sec, H, mirror)
        p.hscale = 1.0 if "Torso" in real else LIMB_H
        p.shorts_y = 0.12 if "UpperLeg" in real else None
        manifest["meshes"] += p.export()
        c = bbox_center(V)
        manifest["parts"][real] = {"bbox_center_world_in_export": [round(float(v), 4) for v in c],
                                   "size": [round(float(v), 4) for v in V.max(0) - V.min(0)]}
    p.name = name

# snatched torso meshes (part-local)
for nm in ("UpperTorso", "LowerTorso"):
    V, F = BODY[nm]; c = bbox_center(V)
    write_obj(os.path.join(OUT, f"Body_{nm}_Snatched.obj"), V - c, F, np.zeros((len(V), 2)))
    manifest["parts"].setdefault(nm, {"bbox_center_world_in_export": [round(float(v), 4) for v in c],
                                      "size": [round(float(v), 4) for v in V.max(0) - V.min(0)]})
    manifest["parts"][nm]["snatched_mesh"] = f"Body_{nm}_Snatched.obj"
json.dump(manifest, open(os.path.join(OUT, "manifest_raw.json"), "w"), indent=1)
json.dump({k: (BODY[k][0].tolist(), BODY[k][1].tolist()) for k in BODY}, open(os.path.join(OUT, "body.json"), "w"))
print(len(manifest["meshes"]), "meshes", sum(m["triangles"] for m in manifest["meshes"]), "tris")

# ---------- upper traps: slope from neck to shoulders on TOP of the UpperTorso (grows along Y) ----------
def upper_traps():
    from scipy.ndimage import gaussian_filter
    V, F = BODY["UpperTorso"]; c = bbox_center(V)
    xs = np.arange(-1.18, 1.1801, 0.025); zs = np.arange(-0.56, 0.5601, 0.025)
    X, Z = np.meshgrid(xs, zs, indexing="xy")
    O = np.stack([X + c[0], np.full_like(X, V[:, 1].max() + 1), Z + c[2]], -1).reshape(-1, 3)
    D = np.tile([0, -1.0, 0], (O.shape[0], 1))
    t = raycast(V, F, O, D).reshape(X.shape)
    ytop = V[:, 1].max() + 1 - t
    # fill gaps/misses (neck socket, past the shoulder edge) and smooth -> no holes
    from scipy.ndimage import distance_transform_edt
    bad = np.isnan(ytop)
    if bad.any():
        idx = distance_transform_edt(bad, return_distances=False, return_indices=True); ytop = ytop[tuple(idx)]
    over = np.clip((np.abs(X) - 0.98) / 0.20, 0, 1)            # drape down over the shoulder joint
    ytop = gaussian_filter(ytop, 2.0) - 0.25 * over ** 1.5
    ok = np.ones_like(ytop, bool)
    ax = np.abs(X)
    u = np.clip((ax - 0.30) / 0.76, 0, 1)                      # 0 at neck, 1 at shoulder joint
    # "most muscular" traps: steep mountain beside the neck, wide thick insertion into the shoulder joint
    rise = np.clip(u / 0.10, 0, 1); rise = rise * rise * (3 - 2 * rise)
    fall = (1 - u) ** 1.1
    prof = rise * (0.28 + 0.72 * fall)
    prof *= 1 - np.clip((ax - 1.06) / 0.12, 0, 1) ** 2           # fade out on top of the delt
    zc = 0.16 - 0.10 * u; zw = 0.36 + 0.14 * u                 # behind the collarbone at the neck, full depth at the shoulder
    zprof = np.clip(1 - ((Z - zc) / zw) ** 4, 0, 1) ** 0.8
    H = 0.52 * PT_TRAP_PUMP * prof * zprof * (ax > 0.30)
    H = gaussian_filter(H, 1.8)
    act = H > 2e-3
    Y = np.where(ok, ytop, np.nan) + H * GROW + 0.012
    idx = -np.ones(X.shape, int); Vs = []; UV = []
    cell = act[:-1, :-1] | act[1:, :-1] | act[:-1, 1:] | act[1:, 1:]
    cell &= ok[:-1, :-1] & ok[1:, :-1] & ok[:-1, 1:] & ok[1:, 1:]
    used = np.zeros(X.shape, bool)
    used[:-1, :-1] |= cell; used[1:, :-1] |= cell; used[:-1, 1:] |= cell; used[1:, 1:] |= cell
    for (i, j) in zip(*np.nonzero(used)):
        idx[i, j] = len(Vs); Vs.append((X[i, j] + c[0], Y[i, j], Z[i, j] + c[2])); UV.append(((X[i, j] + 1) / 2, (Z[i, j] + .6) / 1.2))
    Fs = []
    for (i, j) in zip(*np.nonzero(cell)):
        a, b, cc, d = idx[i, j], idx[i, j + 1], idx[i + 1, j + 1], idx[i + 1, j]
        Fs += [(a, cc, b), (a, d, cc)]
    Vs = np.array(Vs) - c; Fs = np.array(Fs)
    fn = np.cross(Vs[Fs[:, 1]] - Vs[Fs[:, 0]], Vs[Fs[:, 2]] - Vs[Fs[:, 0]])
    if fn[:, 1].sum() < 0: Fs = Fs[:, ::-1]
    write_obj(os.path.join(OUT, "UpperTorso__UpperTraps.obj"), Vs, Fs, np.array(UV))
    base_top = (np.where(ok, ytop, -1e9) - c[1])[used]
    vy = Vs[:, 1]
    kh = float(np.min(np.maximum(base_top, 0.1) / np.maximum(vy, 1e-6))) - 0.03
    bmin, bmax = Vs.min(0), Vs.max(0)
    return {"k_hidden": round(kh, 4), "growth_axis": "Y", "file": "UpperTorso__UpperTraps.obj", "part": "UpperTorso",
            "muscle": "Traps", "triangles": int(len(Fs)), "bbox_center": [round(float(v), 4) for v in (bmin + bmax) / 2],
            "bbox_size": [round(float(v), 4) for v in bmax - bmin], "max_bulge_studs": round(float(H.max()), 4)}
PT_TRAP_PUMP = 1.0
manifest["meshes"].append(upper_traps())
json.dump(manifest, open(os.path.join(OUT, "manifest_raw.json"), "w"), indent=1)
print("upper traps", manifest["meshes"][-1]["k_hidden"], manifest["meshes"][-1]["triangles"])

# ---------- exact hide scale against the REAL body mesh ----------
sys.path.insert(0, os.path.join(HERE, ".."))
from raster import load as _load
for e in manifest["meshes"]:
    if e.get("growth_axis") == "Y": continue
    Vm, Fm = _load(os.path.join(OUT, e["file"]))
    Vb, Fb = BODY[e["part"]]; cb = bbox_center(Vb)
    sel = Vm[::3]
    O = np.stack([np.full(len(sel), cb[0]), sel[:, 1] + cb[1], np.full(len(sel), cb[2])], -1)
    d = np.stack([sel[:, 0], 0 * sel[:, 0], sel[:, 2]], -1); rv = np.linalg.norm(d, axis=1)
    D = d / np.maximum(rv, 1e-6)[:, None]
    t = raycast(Vb, Fb, O, D)
    t = np.where(np.isnan(t), rv * 0.5, t)
    e["k_hidden"] = round(float(np.min(t / np.maximum(rv, 1e-6))) - 0.03, 4)
json.dump(manifest, open(os.path.join(OUT, "manifest_raw.json"), "w"), indent=1)
print("k_hidden range", min(e["k_hidden"] for e in manifest["meshes"]), max(e["k_hidden"] for e in manifest["meshes"]))
