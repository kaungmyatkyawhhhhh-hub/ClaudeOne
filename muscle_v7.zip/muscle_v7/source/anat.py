"""GYM ARC muscle shells v2: anatomy-map based.

Each R15 body part gets a tube-shaped "skin" around it (rounded-box cross-section). The tube surface is
split into muscle regions drawn from an anatomy chart, in (s, y) coordinates:
  s = arc length (studs) around the part, 0 = front center, + toward the character's RIGHT (+X),
  y = height (studs) from the part center.
Each region bulges out with a rounded dome that drops to zero at its border, so neighbours meet in clean
separation grooves and nothing sticks out. One mesh per muscle (sub-regions merged), so each muscle grows
on its own in-game.

Roblox axes: +X = character's right, +Y = up, -Z = front.
"""
import numpy as np, json, os
from scipy.ndimage import distance_transform_edt, gaussian_filter

OUT = os.path.join(os.path.dirname(__file__), "out")
os.makedirs(OUT, exist_ok=True)
RES = 0.0125      # raster for distance fields (studs)
STEP = 0.028     # mesh grid (studs)
LIFT = 0.012
PUMP = 1.35
GROW = 1.0      # 0 = flat on the skin, 1 = max bulge (same vertex order for every value)     # overall fullness at max    # sits this far above the body surface at full size

# ---------------- cross-section ----------------
class Section:
    def __init__(self, W, D, n=4.0):
        th = np.linspace(0, 2 * np.pi, 4001)
        # superellipse; th=0 -> front (-Z), increasing toward +X
        c, s = np.cos(th), np.sin(th)
        x = (W / 2) * np.sign(s) * np.abs(s) ** (2 / n)
        z = -(D / 2) * np.sign(c) * np.abs(c) ** (2 / n)
        P = np.stack([x, z], 1)
        seg = np.linalg.norm(np.diff(P, axis=0), axis=1)
        self.L = np.concatenate([[0], np.cumsum(seg)])
        self.P, self.per = P, self.L[-1]
        t = np.gradient(P, axis=0); t /= np.linalg.norm(t, axis=1, keepdims=True)
        self.N = np.stack([t[:, 1], -t[:, 0]], 1)  # outward
        mid = len(P) // 4
        if (self.N[mid] @ P[mid]) < 0: self.N = -self.N

    def at(self, s):
        s = np.mod(s, self.per)
        x = np.interp(s, self.L, self.P[:, 0]); z = np.interp(s, self.L, self.P[:, 1])
        nx = np.interp(s, self.L, self.N[:, 0]); nz = np.interp(s, self.L, self.N[:, 1])
        nn = np.sqrt(nx ** 2 + nz ** 2)
        return x, z, nx / nn, nz / nn

# ---------------- geometry helpers ----------------
def in_poly(px, py, poly):
    poly = np.asarray(poly); n = len(poly); inside = np.zeros(px.shape, bool)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]; xj, yj = poly[j]
        cond = ((yi > py) != (yj > py)) & (px < (xj - xi) * (py - yi) / (yj - yi + 1e-12) + xi)
        inside ^= cond; j = i
    return inside

def seg_dist(px, py, a, b):
    a, b = np.array(a, float), np.array(b, float); ab = b - a
    t = np.clip(((px - a[0]) * ab[0] + (py - a[1]) * ab[1]) / (ab @ ab + 1e-12), 0, 1)
    return np.hypot(px - (a[0] + t * ab[0]), py - (a[1] + t * ab[1]))

# ---------------- part definition ----------------
class Part:
    def __init__(self, name, W, D, H, regions, mirror_regions=True, veins=(), sym=True):
        """regions: list of (label, muscle, poly(s,y) on RIGHT half or full, height, sharp)"""
        self.name, self.W, self.D, self.H = name, W, D, H
        self.sec = Section(W, D)
        self.regions, self.mirror, self.veins = regions, mirror_regions, veins

    def label_map(self):
        per = self.sec.per
        ns = int(np.ceil(per / RES)); ny = int(np.ceil(self.H / RES)) + 1
        s = (np.arange(ns) + 0.5) * per / ns - per / 2         # -per/2 .. per/2
        y = np.linspace(-self.H / 2, self.H / 2, ny)
        S, Y = np.meshgrid(s, y, indexing="xy")
        lab = np.full(S.shape, -1, int)
        polys = []
        for i, reg in enumerate(self.regions):
            poly = reg[2]
            P = np.asarray(poly, float)
            polys.append((i, P))
            if self.mirror:
                polys.append((i, P * np.array([-1, 1])))
        # paint in reverse so earlier regions win
        for i, P in reversed(polys):
            for shift in (-per, 0, per):
                m = in_poly(S, Y, P + np.array([shift, 0]))
                lab[m] = i * 2 + (0 if P[:, 0].mean() >= 0 else 1) if self.mirror else i
        return S, Y, lab, ns, ny

    def build(self):
        S, Y, lab, ns, ny = self.label_map()
        per = self.sec.per
        Hmap = np.zeros(S.shape)
        nreg = lab.max() + 1
        done = set()
        for k in range(nreg):
            ri = k // 2 if self.mirror else k
            if not (lab == k).any(): continue
            reg = self.regions[ri]
            _, mus, poly, hmax, sharp = reg[:5]
            grp = reg[5] if len(reg) > 5 else None
            if grp:
                side = k % 2 if self.mirror else 0
                ks_g = [kk for kk in range(nreg) if (len(self.regions[kk // 2 if self.mirror else kk]) > 5
                        and self.regions[kk // 2 if self.mirror else kk][5] == grp and (kk % 2 if self.mirror else 0) == side)]
                key = (grp, side)
                if key in done: continue
                done.add(key)
                m = np.isin(lab, ks_g)
            else:
                m = lab == k
            pad = np.pad(m, ((1, 1), (0, 0)), constant_values=False)
            # periodic in s: tile 3x
            T = np.concatenate([pad, pad, pad], 1)
            d = distance_transform_edt(T)[1:-1, ns:2 * ns] * RES
            dm = max(d.max(), 1e-6)
            p = np.clip(d / dm, 0, 1)
            sig = max(0.30 * dm / RES, 1.0)
            T3 = np.concatenate([p, p, p], 1)
            pb = gaussian_filter(T3, sig, mode="nearest")[:, ns:2 * ns]
            pb = pb / max(pb[m].max(), 1e-6)
            edge = np.clip(d / (0.16 * dm + 1e-6), 0, 1)
            edge = 1 - (1 - edge) ** sharp           # crisp separation groove at the border
            prof = np.clip(pb, 0, 1) ** 0.5 * edge   # full, pumped domes
            Hmap = np.where(m, hmax * PUMP * prof, Hmap)
        # veins: raised thin lines, only inside regions
        for (pts, w, amp) in self.veins:
            for sgn in ((1, -1) if self.mirror else (1,)):
                dmin = np.full(S.shape, 9.0)
                P = [(sgn * a, b) for a, b in pts]
                for a, b in zip(P[:-1], P[1:]):
                    dmin = np.minimum(dmin, seg_dist(S, Y, a, b))
                Hmap = Hmap + np.where(lab >= 0, amp * np.exp(-(dmin / w) ** 2), 0)
        self.S, self.Y, self.lab, self.Hmap = S, Y, lab, Hmap

    def muscle_of(self, k):
        ri = k // 2 if self.mirror else k
        return self.regions[ri][1]

    def export(self, mirrorX=False, suffix=""):
        """One OBJ per muscle. Height field per muscle is smoothed, so separation grooves follow smooth curves."""
        from scipy.ndimage import map_coordinates
        per = self.sec.per
        ns = self.Hmap.shape[1]
        nsv = int(round(per / STEP))
        s1 = -per / 2 + np.arange(nsv) * per / nsv
        y1 = np.linspace(-self.H / 2, self.H / 2, int(round(self.H / STEP)) + 1)
        SV, YV = np.meshgrid(s1, y1, indexing="xy")
        ci = (SV + per / 2) / per * ns - 0.5          # raster column coords
        ri = (YV + self.H / 2) / RES                  # raster row coords
        if getattr(self, "surface", None) is not None:
            SP, SN = self.surface(SV, YV)          # real body surface points/normals (part-local)
        else:
            x, z, nx, nz = self.sec.at(SV)
            SP = np.stack([x, YV, z], -1); SN = np.stack([nx, 0 * nx, nz], -1)
        hs = getattr(self, "hscale", 1.0)
        groups = {}
        for k in np.unique(self.lab[self.lab >= 0]):
            groups.setdefault(self.muscle_of(k), []).append(k)
        entries = []
        for mus, ks in groups.items():
            Hm = gaussian_filter(self.Hmap, 1.6, mode=("nearest", "wrap"))
            HV = map_coordinates(Hm, [ri, ci], order=1, mode="grid-wrap")
            reg_of = lambda kk: self.regions[kk // 2 if self.mirror else kk]
            grps = {reg_of(kk)[5] for kk in ks if len(reg_of(kk)) > 5}
            allk = np.unique(self.lab[self.lab >= 0])
            gk = list(ks) + [kk for kk in allk if len(reg_of(kk)) > 5 and reg_of(kk)[5] in grps]
            wgt = gaussian_filter(np.isin(self.lab, gk).astype(float), 1.5, mode=("nearest", "wrap"))
            ownw = map_coordinates(gaussian_filter(np.isin(self.lab, ks).astype(float), 1.0, mode=("nearest", "wrap")), [ri, ci], order=1, mode="grid-wrap")
            w = map_coordinates(wgt, [ri, ci], order=1, mode="grid-wrap")
            w = np.clip((w - 0.02) / 0.6, 0, 1); w = w * w * (3 - 2 * w)
            HV = HV * w
            act = (w > 0) & (HV > 2e-4) & (ownw > 0.02)
            actR = np.roll(act, -1, axis=1)
            cell = act[:-1] | act[1:] | actR[:-1] | actR[1:]
            h = HV + LIFT
            P3 = SP + SN * (HV * hs * GROW + LIFT)[..., None]
            X, Yv, Z = P3[..., 0], P3[..., 1], P3[..., 2]
            if mirrorX: X = -X
            cut = getattr(self, "shorts_y", None)
            YC = (YV[:-1] + YV[1:]) / 2
            variants = [("", cell)] if cut is None else [("", cell & (YC <= cut)), ("_Shorts", cell & (YC > cut))]
            cell_all = cell
            for vsuf, cell in variants:
                idx = -np.ones(SV.shape, int); V = []; UV = []
                used = np.zeros(SV.shape, bool)
                used[:-1] |= cell; used[1:] |= cell
                used[:-1] |= np.roll(cell, 1, axis=1); used[1:] |= np.roll(cell, 1, axis=1)
                for (i, j) in zip(*np.nonzero(used)):
                    idx[i, j] = len(V); V.append((X[i, j], Yv[i, j], Z[i, j]))
                    UV.append(((SV[i, j] + per / 2) / per, (YV[i, j] + self.H / 2) / self.H))
                F = []
                for (i, j) in zip(*np.nonzero(cell)):
                    jn = (j + 1) % nsv
                    a, b, c, d = idx[i, j], idx[i, jn], idx[i + 1, jn], idx[i + 1, j]
                    F += [(a, b, c), (a, c, d)]
                if not F: continue
                V = np.array(V); F = np.array(F)
                fn = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
                fc = V[F].mean(1)
                if (np.sum(fn[:, [0, 2]] * fc[:, [0, 2]])) < 0: F = F[:, ::-1]
                fname = f"{self.name}{suffix}__{mus.replace(' ', '')}{vsuf}.obj"
                write_obj(os.path.join(OUT, fname), V, F, np.array(UV))
                bmin, bmax = V.min(0), V.max(0)
                hmax = float(HV.max() * hs)
                used_m = act
                rb = np.linalg.norm(SP[..., [0, 2]], axis=-1)[used_m]
                rv = np.linalg.norm(P3[..., [0, 2]], axis=-1)[used_m]
                k_hidden = float(np.min(rb / np.maximum(rv, 1e-6))) - 0.10 if rb.size else 0.6
                entries.append({"k_hidden": round(k_hidden, 4), "file": fname, "part": self.name + suffix, "muscle": mus, "shorts": bool(vsuf), "triangles": int(len(F)),
                                "bbox_center": [round(float(v), 4) for v in (bmin + bmax) / 2],
                                "bbox_size": [round(float(v), 4) for v in bmax - bmin],
                                "max_bulge_studs": round(hmax, 4)})
        return entries

def vnorm(V, F):
    N = np.zeros_like(V)
    fn = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    for k in range(3): np.add.at(N, F[:, k], fn)
    return N / (np.linalg.norm(N, axis=1, keepdims=True) + 1e-9)

def write_obj(path, V, F, UV):
    N = vnorm(V, F)
    with open(path, "w") as f:
        f.write("# GYM ARC muscle shell. Part-local coords: +X right, +Y up, -Z front. Studs.\n")
        for v in V: f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
        for t in UV: f.write(f"vt {t[0]:.4f} {t[1]:.4f}\n")
        for n in N: f.write(f"vn {n[0]:.4f} {n[1]:.4f} {n[2]:.4f}\n")
        for a, b, c in F + 1: f.write(f"f {a}/{a}/{a} {b}/{b}/{b} {c}/{c}/{c}\n")
