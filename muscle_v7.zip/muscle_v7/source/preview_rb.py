import sys, os, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, ".."))
from raster import Canvas, load, rotY, rotX
from PIL import Image, ImageDraw
OUT = os.path.join(HERE, "out")
SKIN = (0.85, 0.63, 0.46); SHORTS = (0.13, 0.13, 0.15)
BODY = {k: (np.array(v[0]), np.array(v[1])) for k, v in json.load(open(os.path.join(OUT, "body.json"))).items()}
MAN = json.load(open(os.path.join(OUT, "manifest_raw.json")))
ORIGIN = np.array([0.0, 34.6, -250.0])
CACHE = {}
KMIN = 0.0
SH = {}
def shorts(part, mus): return SH.get((part, mus), False)

def render(R, level, path, W=420, H=560, scale=110, monster=False, original=False):
    c = Canvas(W, H, bg=(0.15, 0.15, 0.17))
    for nm, (V, F) in BODY.items():
        if "UpperLeg" in nm:
            cy = (V[:, 1].min() + V[:, 1].max()) / 2; Hr = np.ptp(V[:, 1])
            cut = cy + 0.12 * Hr * 0.94 / 1.2
            up = V[F].mean(1)[:, 1] > cut
            c.draw(V - ORIGIN, F[up], SHORTS, R=R, scale=scale, offset=(0, 35), spec=0.12)
            c.draw(V - ORIGIN, F[~up], SKIN, R=R, scale=scale, offset=(0, 35), spec=0.12)
            continue
        col = SHORTS if nm == "LowerTorso" else SKIN
        c.draw(V - ORIGIN, F, col, R=R, scale=scale, offset=(0, 35), spec=0.12)
    if level is not None:
        for m in MAN["meshes"]:
            f = os.path.join(OUT, m["file"])
            if f not in CACHE: CACHE[f] = load(f)
            V, F = CACHE[f]
            ctr = np.array(MAN["parts"][m["part"]]["bbox_center_world_in_export"])
            sz = MAN["parts"][m["part"]]["size"]; r = min(sz[0], sz[2]) / 2
            k0 = max(m["k_hidden"], KMIN)
            k = k0 + (1 - k0) * level
            if monster: k = 1.06
            sc = np.array([1, k, 1]) if m.get("growth_axis") == "Y" else np.array([k, 1, k])
            Vw = V * sc + ctr - ORIGIN
            c.draw(Vw, F, SHORTS if m.get("shorts") else SKIN, R=R, scale=scale, offset=(0, 35), spec=0.25, gloss=40)
    c.save(path)

if __name__ == "__main__":
    V = {"front": rotY(np.pi), "back": np.eye(3), "side": rotY(np.pi / 2), "34": rotY(np.pi * 0.8), "34b": rotY(-np.pi * 0.2)}
    jobs = [a.split(":") for a in sys.argv[1:]] or [["front", "1"], ["back", "1"], ["side", "1"], ["34", "1"]]
    tiles = []
    for v, lv in jobs:
        p = os.path.join(OUT, "tmp.png"); render(rotX(0.06) @ V[v], float(lv), p)
        im = Image.open(p).copy(); ImageDraw.Draw(im).text((8, 6), f"{v} {int(float(lv)*100)}%", fill=(230, 230, 230)); tiles.append(im)
    s = Image.new("RGB", (sum(t.width for t in tiles), tiles[0].height)); x = 0
    for t in tiles: s.paste(t, (x, 0)); x += t.width
    s.save(os.path.join(OUT, "preview.png")); print("ok")
